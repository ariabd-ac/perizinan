<div class="footer-left">
  Copyright &copy; 2021 <div class="bullet"></div> Copyright <a href="http://pemalicomal.com/">Pemalicomal</a>
</div>
<div class="footer-right">
  2.3.0
</div>